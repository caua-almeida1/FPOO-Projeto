package br.com.sesi.app;
import java.util.Scanner;
import br.com.sesi.model.Musicas;
import br.com.sesi.model.Podcast;

public class Main {

    public static void main(String[] args) {
        Musicas primeiraMusica = new Musicas();
        Podcast primeiroPodcast = new Podcast();
        
        Scanner scanner = new Scanner(System.in);
        
        // Menu de boas-vindas
        System.out.println("************************************");
        System.out.println("*      Bem-vindo ao Esportify      *");
        System.out.println("************************************");
        System.out.println("Pressione Enter para continuar...");
        scanner.nextLine();

        primeiraMusica.setTitulo("Mais Um Voo");
        primeiraMusica.setArtista("Teto");
        primeiraMusica.setDuracao("4:06");
        primeiraMusica.setReproducoes(2000);
        primeiraMusica.setGenero("Trap");
        primeiraMusica.setCurtidas(10);

        primeiraMusica.imprimeInfo();
        
        while (true) {
            System.out.println();
            System.out.println("Escolha uma op��o: ");
            System.out.println("1 - Escutar a m�sica");
            System.out.println("2 - Curtir a m�sica");
            System.out.println("3 - Sair");
            int opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1:
                    System.out.println("Voc� deseja escutar a m�sica? [S/N]");
                    String lt = scanner.nextLine();
                    
                    if (lt.equalsIgnoreCase("S")) {
                        primeiraMusica.setReproducoes(primeiraMusica.getReproducoes() + 1);
                        System.out.println("Voc� est� ouvindo a m�sica...");
                        primeiraMusica.imprimeInfo();
                    } else if (lt.equalsIgnoreCase("N")) {
                        System.out.println("Ok, muito obrigado!");
                    } else {
                        System.out.println("Op��o inv�lida");
                    }
                    break;

                case 2:
                    System.out.println("Voc� deseja curtir a m�sica? [S/N]");
                    String lt1 = scanner.nextLine();

                    if (lt1.equalsIgnoreCase("S")) {
                        primeiraMusica.setCurtidas(primeiraMusica.getCurtidas() + 1);
                        System.out.println("Voc� curtiu essa m�sica!");
                        primeiraMusica.imprimeInfo();
                    } else if (lt1.equalsIgnoreCase("N")) {
                        System.out.println("Ok, muito obrigado!");
                    } else {
                        System.out.println("Op��o inv�lida");
                    }
                    break;

                case 3:
                    System.out.println("Saindo do programa...");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Op��o inv�lida");
                    break;
            }
        }
    }
}
