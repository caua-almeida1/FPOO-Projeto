package br.com.sesi.model;
import java.util.Scanner;

public class info {
	
	private String titulo;
	private String artista;
	private String duracao;
	private String genero;	

	private int reproducoes;
	private int curtidas;
	
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getArtista() {
		return artista;
	}
	public void setArtista(String artista) {
		this.artista = artista;
	}
	public String getDuracao() {
		return duracao;
	}
	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}
	public int getReproducoes() {
		return reproducoes;
	}
	public void setReproducoes(int reproducoes) {
		this.reproducoes = reproducoes;
	}
	public int getCurtidas() {
		return curtidas;
	}
	public void setCurtidas(int curtidas) {
		this.curtidas = curtidas;
	}
	public String getClassificacao() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	
	
	//Metodo
	
	
	public void imprimeInfo() {
		System.out.println("Titulo: " + getTitulo());
		System.out.println("Artista: " + getArtista());
		System.out.println("Dura��o: " + getDuracao() + " minutos");
		System.out.println("Total de Reprodu��es: " + getReproducoes());
		System.out.println("Total de Curtidas: " + getCurtidas());
	}

}
