package br.com.sesi.model;

public class Podcast extends info{
	
}
